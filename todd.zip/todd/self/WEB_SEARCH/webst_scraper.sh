#!/bin/bash
#**************************************************************************** 
#    
# Check if the TDrc file exists and source it
if [ -f "$HOME/todd/self/.TDrc" ]; then
	. "$HOME/todd/self/.TDrc"  # Source the configuration file
fi
#****************************************************************

if [ -z "$1" ]; then
echo "error: 187 on a mfcop"
sleep 5
exit 1
fi

# Get the word from the command-line argument   DO NOT CHANGE FROM VAR-$1
word="$1"

encoded_word=$(echo "$word" | sed 's/ /%20/g') # Encode for URL compatibility

# Construct the Merriam-Webster URL for the word
url="https://www.merriam-webster.com/dictionary/$word"

# Download the page using curl (more control over headers)
GREEN="\e[38;5;34;40;3;5m"
ENDCOLOR="\e[0m"

echo -e "${GREEN}Learning: '$word' ${ENDCOLOR}"
touch "$TD_DIR/WEB_SEARCH/temp_mw_page.html"
curl -L -s -A "Mozilla/5.0 (X11; Debian; Linux x86_64; rv:93.0) Gecko/20100101 Firefox/93.0" "$url" -o "$TD_DIR/WEB_SEARCH/temp_mw_page.html"

# Check if the file downloaded successfully
file_size=$(stat -c %s "$TD_DIR/WEB_SEARCH/temp_mw_page.html")
if [ "$file_size" -eq 0 ]; then
echo 'no dice... '
sleep 3
exit 1
fi

# Extract the main definition (targeting specific tags/classes for Merriam-Webster)
# We're grabbing the first definition and filtering out unwanted content

KNOWN_DEFINE="$TD_DIR/WEB_SEARCH/WEBST_DEFINED"
echo "$word" > "$KNOWN_DEFINE"
grep -oP '(?<=<span class="dtText">).*?(?=</span>)' "$TD_DIR/WEB_SEARCH/temp_mw_page.html" | sed 's/<[^>]*>//g' >> "$KNOWN_DEFINE"

# Clean up temporary file
rm -rf "$TD_DIR/WEB_SEARCH/temp_mw_page.html"

FILE "$TD_DIR/WEB_SEARCH/WEBST_DEFINED" & 
