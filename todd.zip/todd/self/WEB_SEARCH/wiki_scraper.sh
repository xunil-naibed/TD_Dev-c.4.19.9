#!/bin/bash
#**************************************************************************** 
#    
# Check if the TDrc file exists and source it
if [ -f "$HOME/todd/self/.TDrc" ]; then
	. "$HOME/todd/self/.TDrc"  # Source the configuration file
fi
#****************************************************************
# Get the topic from the command-line argument
topic="$*"
# Encode the topic for URL compatibility (optional, if spaces are present)
encoded_topic=$(echo "$topic" |sed 's/ /%20/g') 

# Construct the Wikipedia URL using the topic
url="https://en.wikipedia.org/wiki/$encoded_topic"

# Download the page using curl with a user-agent to mimic a browser (to avoid blocks)
GREEN="\e[38;5;34;40;3;5m"
ENDCOLOR="\e[0m"
echo -e "${GREEN}Downloading: '$topic' ${ENDCOLOR}"

touch "$TD_DIR/WEB_SEARCH/temp_wiki_page.html"
curl -L -s -A "Mozilla/5.0 (X11; Debian; Linux x86_64; rv:93.0) Gecko/20100101 Firefox/93.0" "$url" -o "$TD_DIR/WEB_SEARCH/temp_wiki_page.html"

# Check if the file size is 0 (which means it didn't download correctly)
file_size=$(stat -c %s "$TD_DIR/WEB_SEARCH/temp_wiki_page.html")
if [ "$file_size" -eq 0 ]; then
echo 'no dice... '
sleep 3
exit 1
fi

echo "$topic" > "$TD_DIR/WEB_SEARCH/WIKI_CONTENT"

tr -d '\n' < "$TD_DIR/WEB_SEARCH/temp_wiki_page.html" > "$TD_DIR/WEB_SEARCH/clean_wiki_page.html"
grep -oP '(?<=<p>).*?(?=</p>)' "$TD_DIR/WEB_SEARCH/clean_wiki_page.html" | sed 's/<[^>]*>//g' >> "$TD_DIR/WEB_SEARCH/WIKI_CONTENT"
xmllint --html --xpath '//p' "$TD_DIR/WEB_SEARCH/clean_wiki_page.html" 2>/dev/null | sed 's/<[^>]*>//g' >> "$TD_DIR/WEB_SEARCH/WIKI_CONTENT"

# grep -oP '(?<=<p>).*?(?=</p>)' "$TD_DIR/WEB_SEARCH/clean_wiki_page.html" | sed 's/<[^>]*>//g' >> "$TD_DIR/WEB_SEARCH/WIKI_CONTENT" up temporary files
rm -rf "$TD_DIR/WEB_SEARCH/temp_wiki_page.html"

# Clean up temporary files
rm -rf "$TD_DIR/WEB_SEARCH/temp_wiki_page.html" "$TD_DIR/WEB_SEARCH/clean_wiki_page.html"


FILE "$TD_DIR/WEB_SEARCH/WIKI_CONTENT" &
