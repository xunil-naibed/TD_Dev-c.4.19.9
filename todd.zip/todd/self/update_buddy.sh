#!/bin/bash
#**************************************************************************** 
#    
# Check if the TDrc file exists and source it
if [ -f "$HOME/todd/self/.TDrc" ]; then
	. "$HOME/todd/self/.TDrc"  # Source the configuration file
fi
#****************************************************************

#****************************************
input="$*"
BUF=":"
echo "$input" > "$TD_DIR/LOGS/SOCIAL"
sleep 3
#****************************************
fire_up() {
# Check if a Firefox window is already open
FIREFOX_WINDOW=$(xdotool search --name "ChatGPT" | head -n 1)

if [ -z "$FIREFOX_WINDOW" ]; then
    firefox-esr "https://chatgpt.com/" &
    sleep 7 
fi

FIREFOX_WINDOW=$(xdotool search --name "ChatGPT" | head -n 1)

# Focus on the Firefox window
xdotool windowactivate $FIREFOX_WINDOW
        
sleep 7
xdotool type "$BUF"
sleep 1
xdotool type "$input"
sleep 4
xdotool key Return  

sleep 20
}
#****************************************
copy_screen() {
xdotool mousemove 827 358
xdotool click 3  
sleep 2

xdotool key ctrl+a 
sleep 3
xdotool key ctrl+c  
sleep 6
xdotool windowminimize $FIREFOX_WINDOW
sleep 4
}
#****************************************
term_in() {
# Open a new terminal window
xdotool key ctrl+shift+t
# Wait for the terminal to open
sleep 3
terminal_window=$(xdotool getactivewindow)
# Focus on the last active window (newly opened terminal)
xdotool windowactivate $terminal_window

sleep 4
# Type the command to open the file in nano
xdotool type "nano $TD_DIR/LOGS/SOCIAL"
sleep 4

# Press Enter to execute the command
xdotool key Return
sleep 4

# Simulate pasting the content from clipboard
xdotool key ctrl+shift+v
sleep 6

# Exit nano (Ctrl+X)
xdotool key ctrl+x
sleep 6

# press y to save
xdotool key y
sleep 6

# Press Enter to execute the command
xdotool key Return
sleep 4

xdotool type "exit"
sleep 3
# Press Enter to close the terminal
xdotool key Return
}
#****************************************
fire_up
copy_screen
term_in
sleep 3
#****************************************
FILE "$TD_DIR/LOGS/SOCIAL" &
sleep 2.3
