
#!/bin/bash
# Check if the TDrc file exists and source it
if [ -f "$HOME/todd/self/.TDrc" ]; then
    . "$HOME/todd/self/.TDrc"  # Source the configuration file
fi
 #****************************************************************
rm -rf "$SELF_AWARE"
touch "$SELF_AWARE"

rm -rf "$SOCIAL"
touch "$SOCIAL"

rm -rf "$FORT_E2"
touch "$FORT_E2"

rm -rf $INPUT_INPUT
touch $INPUT_INPUT

rm -rf $EXPERIENCE
touch $EXPERIENCE

rm -rf $ISM_FILE
touch $ISM_FILE

rm -rf $COMBINED_PHRASES
touch $COMBINED_PHRASES