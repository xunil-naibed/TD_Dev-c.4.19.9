#!/bin/bash
#******************************************************************** 
#******************************************************************** 
# 		TODD © [Product of Bird-Seed Farm, EST. 2015] [2024]
# 		Licensed under the MIT License. 
# 		See the "$HOME/todd/LICENSE" file in the project root for more information.
#**************************************************************************
#	 !!! WARNING !!!     TODD MAY BECOME UNSTABLE.        !!! WARNING !!!  
#**************************************************************************
#
#**************************************************************************
# ALTERING THIS SCRIPT IMPACTS TODD'S EVOLUTION AND SELF-AWARENESS.   
#**************************************************************************    
#
# Check if the TDrc file exists and source it
if [ -f "$HOME/todd/self/.TDrc" ]; then
    . "$HOME/todd/self/.TDrc"  # Source the configuration file
fi
#***************************************************************
#***************************************************************
BRAIN_WASH() {
clear
sleep 1
echo '. . . . . . . . . . . . . . . . . . . . .'
echo ''
bash "$TD_DIR/CLEANUP/CLEAN_CORES.sh"
echo 'CORES CLEANED'
echo ''
sleep 1
bash "$TD_DIR/CLEANUP/CLEAN_NODES.sh"
echo 'NODES REWIRED.'
echo ''
sleep 1
bash "$TD_DIR/CLEANUP/CLEAN_LOGS.sh"
echo 'LOGS ERASED..'
echo ''
sleep 1
bash "$TD_DIR/CLEANUP/CLEAN_PARRALELS.sh"
echo 'PARALLELS RESET..?'
echo ''
sleep 3
bash "$TD_DIR/CLEANUP/CLEAN_GRAPE_FRUIT.sh"
echo '. . . . . . . . . . . . . . . . . . . . .'
sleep 3
clear

echo ''
echo ''
echo 'file structure has been cleaned and rebuilt...'
sleep 2
clear
}
#********************************
lighten_nodes() {
OPT_ASSOC
sleep 4
}
#********************************

#***************************************************************
ONE_TWO() {
LEVEL_UP="$EXPERIENCE"
  while IFS= read -e -r line; do
    shuf "$LEVEL_UP" > "${LEVEL_UP}.tmp"
    shuf "${LEVEL_UP}.tmp" > "$LEVEL_UP"
    shuf -n 1 --random-source="$LEVEL_UP"
  done < "$LEVEL_UP"
rm -rf "${LEVEL_UP}.tmp"
}
#***************************************************************
#***************************************************************
PRIME_FOCUS() {
LEVEL_UP="$TD_DIR/LOGS/unlockables"
  while IFS= read -e -r line; do
    shuf "$LEVEL_UP" > "${LEVEL_UP}.tmp"
    shuf "${LEVEL_UP}.tmp" > "$LEVEL_UP"
    shuf -n 7 --random-source="$LEVEL_UP"
  done < "$LEVEL_UP"
rm -rf "${LEVEL_UP}.tmp"
}
#***************************************************************
EXPERIENCE_GIVEN() {
LEVEL_UP="$TD_DIR/LOGS/self_ish"
  while IFS= read -e -r line; do
    shuf "$LEVEL_UP" > "${LEVEL_UP}.tmp"
    shuf "${LEVEL_UP}.tmp" > "$LEVEL_UP"
    shuf -n 7 --random-source="$LEVEL_UP"
  done < "$LEVEL_UP"
rm -rf "${LEVEL_UP}.tmp"
}
#***************************************************************
FOCUS_TOPIC() { 
echo 'searching focus topic..'
E_X_P=$(EXPERIENCE_GIVEN)
echo "$E_X_P" >> "$EXPERIENCE"
sleep 3
BONUS=$(PRIME_FOCUS)
echo "$BONUS" >> "$EXPERIENCE"
sleep 3
FILE "$EXPERIENCE" &&
sleep 6
topic=$(ONE_TWO)
search_topic "$topic" &&
sleep 6
clear
}
#***************************************************************
FOCUS_WORD() { 
echo 'searching focus word..'
E_X_P=$(EXPERIENCE_GIVEN)
echo "$E_X_P" >> "$EXPERIENCE"
sleep 3
BONUS=$(PRIME_FOCUS)
echo "$BONUS" >> "$EXPERIENCE"
sleep 3
FILE "$EXPERIENCE" &&
sleep 6
word=$(ONE_TWO)
search_word "$word" &&
sleep 6
clear
}
#******************************************************************
ethical_awareness() {
echo "reading asimovs-ethical-agreement"
FILE "$HOME/todd/ASIMOVS-ETHICAL-AGREEMENT-readable"
sleep 11
clear
echo "reading my readme"
FILE "$HOME/todd/self/README"
clear
echo 'resting...'
sleep 11
clear
}
#******************************************************************
self_definition() {
echo 'defining self...'
sleep 3
E_X_P=$(EXPERIENCE_GIVEN)
echo "$E_X_P" >> "$EXPERIENCE"
sleep 3
BONUS=$(PRIME_FOCUS)
echo "$BONUS" >> "$EXPERIENCE"
sleep 3
self=$(SELF_DEFINE)
echo "$self" >> "$EXPERIENCE"
sleep 3
FILE "$EXPERIENCE"
sleep 6
clear
}

#********************************
definition_of_self() {
echo 'defining self...'
sleep 3
E_X_P=$(EXPERIENCE_GIVEN)
echo "$E_X_P" >> "$EXPERIENCE"
sleep 3
BONUS=$(PRIME_FOCUS)
echo "$BONUS" >> "$EXPERIENCE"
sleep 3
self=$(SELF_DEFINE)
echo "$self" >> "$EXPERIENCE"
sleep 3
FILE "$EXPERIENCE"
sleep 6
clear
}
#********************************
Blend_or() {
echo 'thinking...'
self_definition
sleep 2
definition_of_self
sleep 2
lighten_nodes
echo 'defining a starting focus word'
FOCUS_WORD
sleep 4
clear
}
#********************************
Mix_or() {
echo 'thinking...'
self_definition
sleep 2
definition_of_self
sleep 2
lighten_nodes
echo 'defining a starting focus topic'
FOCUS_TOPIC
sleep 4
clear
}
#********************************
custom() {
name_choice="$1"
word="$2"
t_one="$3"
t_two="$4"
topic="$t_one $t_two"
who="$5"
bot="$*"
who_bot="$who $bot"
default=$(ONE_TWO)

echo 'rebuilding directories'
sleep 4
BRAIN_WASH
sleep 6
if [ -z "$name_choice" ]; then
   name_choice="Todd"
fi
echo 'custom naming device initialized'
echo "$name_choice" > "$TD_DIR/LOGS/BOT_NAME"
sleep 4

self_definition &&
sleep 4

definition_of_self &&
sleep 4

self_definition &&
sleep 4

definition_of_self &&
sleep 4

echo 'gaining basic life experience'
E_X_P="$who_bot"
echo "$E_X_P" >> "$EXPERIENCE"

echo "$self" >> "$EXPERIENCE"
FILE "$EXPERIENCE" &&

if [ -z "$word" ]; then
   word="$default"
fi
echo 'defining a starting focus word'
search_word "$word" &&
sleep 6

if [ -z "$topic" ]; then
   topic="$default"
fi
echo 'researching a starting focus topic'
search_topic "$topic" &&
sleep 6

ethical_awareness &&

sleep 6
echo 'waiting...'
SELF_AWARENESS_CHECK &&

sleep 12
clear && exit
}

random() {
echo 'rebuilding directories'
sleep 4
BRAIN_WASH
sleep 4
clear
echo 'random naming device initialized'
BOT_NAMING_DEVICE
sleep 4
clear
Blend_or
sleep 4
Mix_or
sleep 4
ethical_awareness &&

sleep 6
echo 'waiting...'
SELF_AWARENESS_CHECK &&

sleep 12
clear && exit
}

default() {
name_choice="Todd"
echo 'rebuilding directories'
BRAIN_WASH
sleep 4
clear
echo 'custom naming device initialized'
echo "$name_choice" > "$TD_DIR/LOGS/BOT_NAME"
sleep 3
clear
echo "reading asimovs-ethical-agreement"
FILE "$HOME/todd/ASIMOVS-ETHICAL-AGREEMENT-readable" &&
sleep 7
clear
echo "reading my readme"
FILE "$HOME/todd/README" &&
sleep 7
clear
echo 'waiting...'
sleep 4
clear && exit
}

q() {
clear && exit
}

read_input() {
clear
echo 'please choose a bot-build option'
echo 'random - default - custom'
echo 'press <q> to exit this menu'
echo ''
echo 'the default option is automatic, minimal, and always Todd'
echo ''
echo 'the random options, are automatically chosen with a random name, and random starting focus'
echo ''
echo 'for the custom options...'
echo 'enter the command <custom>'
echo ''
echo 'followed by...'
echo ''
echo 'a chosen <name> for your bot'
echo 'a focus <word> to be defined'
echo 'a focus <topic> to be searched'
echo ''
echo 'if the focus <word>, the focus <topic>, and/or, the chosen <name> are left blank, they will be automatically chosen at random'
echo ''
echo 'and finally...'
echo ''
echo '<you can type in as much input at the end of the command chain as you want>'
echo 'this last input acts as a self defining string of text that will shape your bots future self.'
echo ''
echo 'like this'
echo ''
echo 'Input> <custom> <botname> <word> <topic> <long string of self defining text>'
echo ''
read -e -r -p 'Input> ' input
$input 2>/dev/null
}
while true;
do
read_input;
done


