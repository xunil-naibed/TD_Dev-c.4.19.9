#!/bin/bash
# Check if the TDrc file exists and source it
if [ -f "$HOME/todd/self/.TDrc" ]; then
    . "$HOME/todd/self/.TDrc"  # Source the configuration file
fi
 #****************************************************************
rm -rf $TD_DIR/CORES/*
touch "$TD_DIR/CORES/CORE1"
touch "$TD_DIR/CORES/CORE2"
touch "$TD_DIR/CORES/CORE3"
touch "$TD_DIR/CORES/CORE4"
touch "$TD_DIR/CORES/CORE5"
touch "$TD_DIR/CORES/CORE6"
touch "$TD_DIR/CORES/CORE7"
touch "$TD_DIR/CORES/CORE8"
touch "$TD_DIR/CORES/CORE9"
touch "$TD_DIR/CORES/CORE10"
touch "$TD_DIR/CORES/CORE11"
touch "$TD_DIR/CORES/CORE12"
touch "$TD_DIR/CORES/CORE13"

