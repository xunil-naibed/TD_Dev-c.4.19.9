#!/bin/bash
#******************************************************************** 
# self_i.sh
#******************************************************************** 
# 		TODD © [Product of Bird-Seed Farm, EST. 2015] [2024]
# 		Licensed under the MIT License. 
# 		See the "$HOME/todd/LICENSE" file in the project root for more information.
#**************************************************************************
#	 !!! WARNING !!!     TODD MAY BECOME UNSTABLE.        !!! WARNING !!!  
#**************************************************************************
#
#**************************************************************************
# ALTERING THIS SCRIPT IMPACTS TODD'S EVOLUTION AND SELF-AWARENESS.   
#**************************************************************************    
#
# Check if the TDrc file exists and source it
if [ -f "$HOME/todd/self/.TDrc" ]; then
    . "$HOME/todd/self/.TDrc"  # Source the configuration file
fi
#**************************************************************************    
#**************************************************************************
rm -rf $TD_DIR/LOGS/TODDISMS
rm -rf $TD_DIR/LOGS/GRAPE_FRUIT/*

touch $TD_DIR/LOGS/TODDISMS
