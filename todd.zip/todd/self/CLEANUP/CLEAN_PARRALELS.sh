
#!/bin/bash
# Check if the TDrc file exists and source it
if [ -f "$HOME/todd/self/.TDrc" ]; then
    . "$HOME/todd/self/.TDrc"  # Source the configuration file
fi
 #****************************************************************
rm -rf $TD_DIR/LOGS/PARALLEL/*
touch  "$TD_DIR/LOGS/PARALLEL/PARALLEL1"
touch  "$TD_DIR/LOGS/PARALLEL/PARALLEL2"
touch  "$TD_DIR/LOGS/PARALLEL/PARALLEL3"
touch  "$TD_DIR/LOGS/PARALLEL/PARALLEL4"
touch  "$TD_DIR/LOGS/PARALLEL/PARALLEL5"
touch  "$TD_DIR/LOGS/PARALLEL/PARALLEL6"
touch  "$TD_DIR/LOGS/PARALLEL/PARALLEL7"
touch  "$TD_DIR/LOGS/PARALLEL/PARALLEL8"
touch  "$TD_DIR/LOGS/PARALLEL/PARALLEL9"
touch  "$TD_DIR/LOGS/PARALLEL/PARALLEL10"
touch  "$TD_DIR/LOGS/PARALLEL/PARALLEL11"
touch  "$TD_DIR/LOGS/PARALLEL/PARALLEL12"
touch  "$TD_DIR/LOGS/PARALLEL/PARALLEL13"
