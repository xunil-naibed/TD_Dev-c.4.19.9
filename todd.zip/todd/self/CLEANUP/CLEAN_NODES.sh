
#!/bin/bash
# Check if the TDrc file exists and source it
if [ -f "$TD_DIR/.TDrc" ]; then
    . "$TD_DIR/.TDrc"  # Source the configuration file
fi
#****************************************************************
rm -rf $TD_DIR/NODES/*
touch "$TD_DIR/NODES/NODE1"
touch "$TD_DIR/NODES/NODE2"
touch "$TD_DIR/NODES/NODE3"
touch "$TD_DIR/NODES/NODE4"
touch "$TD_DIR/NODES/NODE5"
touch "$TD_DIR/NODES/NODE6"
touch "$TD_DIR/NODES/NODE7"
touch "$TD_DIR/NODES/NODE8"
touch "$TD_DIR/NODES/NODE9"
touch "$TD_DIR/NODES/NODE10"
touch "$TD_DIR/NODES/NODE11"
touch "$TD_DIR/NODES/NODE12"
touch "$TD_DIR/NODES/NODE13"

