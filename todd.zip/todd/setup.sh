#!/bin/bash
clear
apt update
sleep 0.6
echo ""
echo "               T0db0T/Linux/GNU/X11"

while IFS= read -r pkg; do
  if ! dpkg -l | grep -q "$pkg"; then
    echo "Installing $pkg..."
    apt install -y "$pkg"
    sleep 0.6
  else
    echo "$pkg is already installed."
  fi
done < "$HOME/todd/PKGS"
sleep 0.6
echo ""
echo "               T0db0T/Linux/GNU/X11"
sleep 3
echo "       package Installation process complete."

sleep 5
